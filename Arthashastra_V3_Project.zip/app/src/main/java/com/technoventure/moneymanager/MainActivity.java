package com.technoventure.moneymanager;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.content.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends FragmentActivity {
    private WebView web;
    private boolean exitRequested = false;
    private android.content.SharedPreferences prefs;
    private static final String PREF="mmm_secure";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(15,23,42));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(15,23,42));
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        web=new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(248,250,252));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(),"Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private String hash(String s) {
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            return Base64.encodeToString(md.digest(s.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
        } catch(Exception e){ return ""; }
    }
    public class Bridge {
        @JavascriptInterface public void exitApp(){ runOnUiThread(() -> { exitRequested=true; finish(); }); }
        @JavascriptInterface public boolean hasPin(){ return prefs.contains("pin_hash"); }
        @JavascriptInterface public boolean verifyPin(String p){ return hash(p).equals(prefs.getString("pin_hash","")); }
        @JavascriptInterface public boolean setPin(String p){
            if(p==null || !p.matches("[0-9]{6}")) return false;
            prefs.edit().putString("pin_hash",hash(p)).apply(); return true;
        }
        @JavascriptInterface public boolean biometricAvailable(){
            return androidx.biometric.BiometricManager.from(MainActivity.this).canAuthenticate(
                androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG |
                androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS;
        }
        @JavascriptInterface public void authenticateBiometric(){
            runOnUiThread(() -> {
                BiometricPrompt prompt=new BiometricPrompt(MainActivity.this,
                    ContextCompat.getMainExecutor(MainActivity.this),
                    new BiometricPrompt.AuthenticationCallback(){
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){
                            web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true)",null);
                        }
                        @Override public void onAuthenticationError(int c, CharSequence e){
                            web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)",null);
                        }
                        @Override public void onAuthenticationFailed(){
                            web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)",null);
                        }
                    });
                BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock Arthashastra")
                    .setSubtitle("Verify your identity")
                    .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG |
                        androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    .build();
                prompt.authenticate(info);
            });
        }
    }
    @Override public void onBackPressed(){
        if(web!=null) web.evaluateJavascript("window.handleBack && window.handleBack()",null);
        else super.onBackPressed();
    }
}
