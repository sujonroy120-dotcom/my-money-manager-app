Arthashastra V3 - Android Project

ফিচার/পরিবর্তন:
- অ্যাপের নাম Arthashastra
- নতুন Launcher Icon
- Exit App বাটন ও Exit confirmation
- Android Back: আগে modal বন্ধ করবে, তারপর Dashboard-এ ফিরবে, Dashboard-এ থাকলে Exit confirmation দেখাবে
- Light/Dark Theme (Settings থেকে নির্বাচন; পছন্দ সংরক্ষিত থাকে)
- আগের Package ID অপরিবর্তিত: com.technoventure.moneymanager
- আগের localStorage data key অপরিবর্তিত: mmm_v2_data

Build:
GitHub Actions-এ push বা Actions > Build Arthashastra APK > Run workflow ব্যবহার করুন।
সফল হলে Arthashastra-V3-APK artifact থেকে app-debug.apk ডাউনলোড করুন।

গুরুত্বপূর্ণ:
এটি debug build। Android-এ পুরোনো ইনস্টলেশনের ওপর আপডেট দিতে signing key একই থাকতে হবে। GitHub Actions-এর সাধারণ debug signing key প্রতিবার আলাদা হতে পারে; signature mismatch হলে পুরোনো অ্যাপ uninstall করবেন না—আগে ডেটা backup/export করুন এবং স্থায়ী signing key সেটআপ করতে হবে।
