ARTHASHASTRA V4.0 — BANGLA README

এই প্রজেক্টটি Android WebView ভিত্তিক অফলাইন Personal Finance Manager।
Package ID অপরিবর্তিত: com.technoventure.moneymanager
পুরোনো V2 ডেটার localStorage key অপরিবর্তিত: mmm_v2_data
Android PIN preference key অপরিবর্তিত: mmm_secure / pin_hash

V4 ফিচার:
- Dashboard: available cash, monthly income/expense/savings/net flow, asset and loan summary
- Transactions: Income, Expenses, Discretionary, Savings, Loan Payment; month/type/search filters
- Accounts: Cash, Bank, bKash, Nagad, Rocket; opening balance and account transfers
- Savings: savings goals, DPS and FDR planning, configurable rate/term/tax assumptions, actual contribution records
- Loans: loan record, reducing-balance EMI estimate, outstanding balance and repayment entry
- Installments: due-date list and paid/unpaid tracking
- Budget: overall and category budgets; budget includes Expenses, Discretionary and Loan Payment
- Reports: monthly/yearly/all-time cash flow, category and account summaries, CSV export
- JSON backup/restore, PIN, Android biometric/device unlock, Light/Dark theme
- Android-native Exit confirmation; Android Back closes dialogs, returns to Dashboard, then asks to exit

গুরুত্বপূর্ণ আর্থিক সীমাবদ্ধতা:
- DPS/FDR ও EMI-এর অঙ্ক পরিকল্পনামূলক estimate; ব্যাংকের প্রকৃত product rules, compounding, fees, tax/TDS, excise duty, VAT, insurance, early encashment ও rate changes আলাদা হতে পারে।
- কর/withholding rate ব্যবহারকারী নিজে দেবেন; কোনো নির্দিষ্ট ব্যাংক বা সরকারি করহার hard-code করা হয়নি।
- ব্যাংক/MFS sync, cloud sync, push notification, automatic bank statement import নেই। সব transaction হাতে যোগ করতে হবে।
- PIN lock data encryption নয়; local app data encrypted নয়। ফোনের screen lock ব্যবহার করুন এবং JSON backup নিরাপদে রাখুন।

Build:
GitHub Actions workflow: .github/workflows/build-apk.yml
Actions > Build Arthashastra V4 APK > Run workflow (যদি push-এ স্বয়ংক্রিয়ভাবে শুরু না হয়)।
Artifact: Arthashastra-V4-APK > app-debug.apk

Compatibility:
Android package ID একই রাখা হয়েছে। কিন্তু GitHub hosted runner-এ প্রতিবার নতুন debug signing key তৈরি হতে পারে। তাই আগের APK-এর উপর সরাসরি update install নাও হতে পারে। আগে অ্যাপের Settings > Backup & Restore থেকে JSON backup নিন। Signature mismatch হলে পুরোনো app uninstall করার আগে backup নিশ্চিত করুন; uninstall করলে app-local data মুছে যাবে।

এই সোর্সে JavaScript syntax, XML structure এবং ZIP integrity যাচাই করা হয়েছে। Android SDK build ও বাস্তব ফোন পরীক্ষা এই প্যাকেজ তৈরির সময় করা হয়নি।
