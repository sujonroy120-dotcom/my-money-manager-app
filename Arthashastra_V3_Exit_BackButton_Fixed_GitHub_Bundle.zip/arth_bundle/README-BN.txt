ARTHASHASTRA V3 - EXIT / BACK BUTTON FIX

এই আপডেটে সংশোধন:
1. Exit App বাটনে চাপলে Android-এর নিজস্ব Exit Confirmation Dialog দেখাবে।
2. Dialog-এ Exit চাপলে অ্যাপ বন্ধ হবে; Cancel চাপলে অ্যাপ খোলা থাকবে।
3. Android Back Button: খোলা Transaction modal থাকলে modal বন্ধ হবে; অন্য tab-এ থাকলে Dashboard-এ ফিরবে; Dashboard-এ থাকলে Exit Confirmation দেখাবে।
4. WebView JavaScript alert/confirm/prompt dialog support যোগ করা হয়েছে।
5. Package ID এবং existing localStorage key অপরিবর্তিত রাখা হয়েছে।

GitHub upload:
- এই ZIP Extract করুন।
- Extract করা arth_bundle/.github/workflows/build-apk.yml ফাইলটি Repository-তে .github/workflows/build-apk.yml path-এ রাখুন।
- Arthashastra_V3_Project.zip ফাইলটি Repository root-এ upload/replace করুন।
- Commit changes দিন; তারপর Actions-এ Build Arthashastra APK workflow দেখুন।

সতর্কতা: JavaScript syntax, XML ও ZIP integrity যাচাই করা হয়েছে। Android SDK দিয়ে APK build এবং Samsung ফোনে বাস্তব পরীক্ষা এই পরিবেশে করা যায়নি। তাই Build সফল হলে APK ইনস্টল করে পরীক্ষা করুন। পুরোনো অ্যাপ এখনই uninstall করবেন না। আগে ডেটা backup রাখুন।
