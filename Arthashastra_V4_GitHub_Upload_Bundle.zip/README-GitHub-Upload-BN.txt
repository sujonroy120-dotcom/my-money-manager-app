ARTHASHASTRA V4 — GITHUB ZIP UPLOAD BUNDLE

আপনার GitHub Repository-তে সরাসরি Project ZIP আপলোড করে APK build করার জন্য।

এই Bundle Extract করলে পাবেন:
1) Arthashastra_V4_Project.zip — সম্পূর্ণ Android Project
2) .github/workflows/build-apk.yml — ZIP Extract করে APK build করার Workflow
3) README-BN.txt — ফিচার, হিসাবের সীমাবদ্ধতা ও সতর্কতা

GitHub-এ প্রথমবার সেটআপ:
1. Repository খুলুন: https://github.com/sujonroy120-dotcom/my-money-manager-app
2. Add file > Upload files নির্বাচন করুন।
3. এই Bundle Extract করার পর এর ভেতরের জিনিসগুলো Repository Root-এ আপলোড করুন:
   - Arthashastra_V4_Project.zip
   - .github/workflows/build-apk.yml (পুরো .github ফোল্ডারসহ)
   - README-BN.txt
4. Commit changes করুন। ZIP ফাইলটি সরাসরি Repository-তে থাকবে; Workflow সেটি Extract করে Build করবে।
5. Actions ট্যাবে Build Arthashastra V4 APK দেখুন। Push থেকে স্বয়ংক্রিয়ভাবে শুরু না হলে Run workflow চাপুন।
6. Build সফল হলে Artifacts থেকে Arthashastra-V4-APK ডাউনলোড করুন। ZIP Extract করে app-debug.apk ফোনে ইনস্টল করুন।

গুরুত্বপূর্ণ:
- শুধু Project ZIP আপলোড করলে GitHub সেটি নিজে থেকে Build করবে না; .github/workflows/build-apk.yml একবার Repository-তে থাকতে হবে।
- পুরোনো Repository মুছবেন না। Workflow নতুন app/ এবং Gradle project files প্রতিস্থাপন করবে।
- নতুন APK ইনস্টল করার আগে Settings > Backup & Restore থেকে JSON backup নিন।
- GitHub-hosted debug builds-এর signing key প্রতিবার আলাদা হতে পারে। Signature mismatch হলে পুরোনো APK-এর উপর update install হবে না। তখন Backup নিশ্চিত না করে পুরোনো অ্যাপ uninstall করবেন না।
- APK Build এবং বাস্তব ফোনে পরীক্ষা এখনো হয়নি।
