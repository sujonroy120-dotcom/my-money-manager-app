MY MONEY MANAGER V2.0

প্রজেক্টে অন্তর্ভুক্ত:
- Excel-এর Daily / Monthly / Annual Cash Flow ধারণা
- Income, Expenses, Discretionary, Savings আলাদা transaction type
- Expenses + Discretionary একত্রে মাসিক বাজেট গণনা
- 80%, 90% এবং 100% budget warning
- 6-digit PIN; Android BiometricPrompt (Fingerprint / device credential)
- Offline local storage, JSON backup/restore
- Monthly/Annual/All-time reports

গুরুত্বপূর্ণ:
1. এই ZIP সরাসরি APK নয়; GitHub Actions দিয়ে APK build করতে হবে।
2. Build সফল হলে Actions > run > Artifacts থেকে My-Money-Manager-V2-APK ডাউনলোড করুন।
3. APK install করার আগে ফোনের ডেটা/Backup নিজের কাছে নিরাপদে রাখুন।
4. Biometric unlock-এর জন্য ফোনে fingerprint/device credential configured থাকতে হবে।
5. এই সংস্করণটি প্রাথমিক পূর্ণাঙ্গ ভিত্তি; বাস্তব ডিভাইসে build/install/test না করা পর্যন্ত 100% error-free দাবি করা হচ্ছে না।
