package com.technoventure.moneymanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.core.content.ContextCompat;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import android.util.Base64;

public class MainActivity extends FragmentActivity {
    private WebView web;
    private boolean pageReady = false;
    private boolean exitDialogVisible = false;
    private static final String PREF = "mmm_secure";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(15, 23, 42));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(15, 23, 42));
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(241, 245, 249));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                super.onPageFinished(view, url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        setContentView(web);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (exitDialogVisible) return;
                if (!pageReady || web == null) { showExitConfirmation(); return; }
                web.evaluateJavascript("(function(){try{return !!(window.handleAndroidBack && window.handleAndroidBack());}catch(e){return false;}})()", value -> {
                    if (!"true".equals(value)) showExitConfirmation();
                });
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private String hash(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return Base64.encodeToString(digest.digest(value.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    public class AndroidBridge {
        @android.webkit.JavascriptInterface public void requestExitConfirmation() {
            runOnUiThread(() -> showExitConfirmation());
        }
        @android.webkit.JavascriptInterface public boolean hasPin() {
            return getSharedPreferences(PREF, MODE_PRIVATE).contains("pin_hash");
        }
        @android.webkit.JavascriptInterface public boolean verifyPin(String pin) {
            return pin != null && hash(pin).equals(getSharedPreferences(PREF, MODE_PRIVATE).getString("pin_hash", ""));
        }
        @android.webkit.JavascriptInterface public boolean setPin(String pin) {
            if (pin == null || !pin.matches("[0-9]{6}")) return false;
            getSharedPreferences(PREF, MODE_PRIVATE).edit().putString("pin_hash", hash(pin)).apply();
            return true;
        }
        @android.webkit.JavascriptInterface public boolean biometricAvailable() {
            return androidx.biometric.BiometricManager.from(MainActivity.this).canAuthenticate(
                androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG |
                androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS;
        }
        @android.webkit.JavascriptInterface public void authenticateBiometric() {
            runOnUiThread(() -> {
                BiometricPrompt prompt = new BiometricPrompt(MainActivity.this,
                    ContextCompat.getMainExecutor(MainActivity.this),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            if (web != null) web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true)", null);
                        }
                        @Override public void onAuthenticationError(int code, CharSequence message) {
                            if (web != null) web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null);
                        }
                        @Override public void onAuthenticationFailed() {
                            if (web != null) web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null);
                        }
                    });
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock Arthashastra")
                    .setSubtitle("Verify your identity")
                    .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG |
                        androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    .build();
                prompt.authenticate(info);
            });
        }
    }

    private void showExitConfirmation() {
        if (isFinishing() || isDestroyed() || exitDialogVisible) return;
        exitDialogVisible = true;
        new AlertDialog.Builder(this)
            .setTitle("Exit Arthashastra?")
            .setMessage("Are you sure you want to close the app?")
            .setPositiveButton("Exit", (dialog, which) -> {
                exitDialogVisible = false;
                finishAndRemoveTask();
            })
            .setNegativeButton("Cancel", (dialog, which) -> {
                exitDialogVisible = false;
                dialog.dismiss();
            })
            .setOnCancelListener(dialog -> exitDialogVisible = false)
            .show();
    }

    @Override protected void onDestroy() {
        pageReady = false;
        if (web != null) { web.removeJavascriptInterface("Android"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
